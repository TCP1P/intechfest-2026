Tower of Babel — player handout
================================

Shared King-of-the-Hill arena. The archive contains this briefing and a
terminal lobby.

## Start the lobby

  python3 client.py --host <issued-host> --port 1094

The lobby joins the current wave, shows `INFO`/`STATUS`, displays a short PRTS
briefing, and opens a console for the public protocol. It requests the
capability with a hidden prompt and never prints it.

## Protocol

  HELLO koth_<current-capability>
  INFO
  RELAY <lowercase-even-hex-of-the-outermost-stage>
  AUTH <the four printed stage secrets concatenated in build-order>
  PATCH {"patterns":[{"arch":"amd64","hex":"4889"}]}
  QUIT

`INFO` returns the wave, build order, architecture, opaque stage paths, active
ward, and ward status. The four ABIs are:

  amd64       openat=257 read=0 write=1 close=3 execve=59
  aarch64     openat=56  read=63 write=64 close=57 execve=221
  riscv64     openat=56  read=63 write=64 close=57 execve=221
  mips64be    open=5002  read=5000 write=5001 close=5003 execve=5057

The outer payload is limited to 32768 bytes. Each stage reads its own secret,
writes it to stdout, and `execve`s the next executor with the next stage as
NUL-terminated hexadecimal. The target uses a bounded Unicorn VM and does not
execute player bytes natively.

The first team to complete and authenticate all four stages may submit up to
three patches per wave. A patch has at most eight 2–8-byte patterns, no more
than 32 pattern bytes, and may not match a mandatory syscall opcode. The target
replays the first solver's known-good relay before activation. Rejection keeps
the previous ward and reports `previous-known-good`; acceptance applies to
later attempts and future waves. The budget survives reconnects.

Unauthenticated `PING` returns `PONG`; `INFO` is read-only.
