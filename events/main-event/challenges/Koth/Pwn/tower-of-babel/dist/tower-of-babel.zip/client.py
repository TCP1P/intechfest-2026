#!/usr/bin/env python3
"""Interactive player lobby for Tower of Babel."""

from __future__ import annotations

import argparse
import getpass
import json
import socket
import sys
import textwrap
import time
from typing import Any


MAX_LINE_BYTES = 70 * 1024
SOCKET_TIMEOUT_SECONDS = 4

LORE = """
PRTS // YEAR 1094 // KAZDEL
Doctor / x86-64, Kal'tsit / AArch64, Theresa / RISC-V 64,
Civilight Eterna / MIPS64 BE. Theresa entrusted the crown to Amiya.
"""

RULES = """
1. Join with the current rsctf KotH capability.
2. Read INFO before building anything: paths and architecture order change per wave.
3. RELAY sends lowercase even-length hex; AUTH proves the four printed secrets.
4. babel-mastery ranks stage depth first, then the outer payload size.
5. Only the first authenticated full solver may submit three patches in that wave.
6. Patches are replay-canary-tested. Rejection keeps the previous known-good ward.
7. PING, INFO, STATUS, and this lobby do not change your score.
"""


class ProtocolError(RuntimeError):
    """The target did not satisfy the public Tower protocol."""


class BabelConsole:
    def __init__(self, host: str, port: int, token: str | None = None) -> None:
        self.host = host
        self.port = port
        self.token = token
        self.sock: socket.socket | None = None
        self.reader: Any = None
        self.info: dict[str, Any] | None = None
        self.joined = False

    def connect(self) -> None:
        try:
            self.sock = socket.create_connection(
                (self.host, self.port), timeout=SOCKET_TIMEOUT_SECONDS
            )
            self.sock.settimeout(SOCKET_TIMEOUT_SECONDS)
            self.reader = self.sock.makefile("rb")
            greeting = self._readline()
            prompt = self._readline()
        except (OSError, UnicodeError) as error:
            self.close()
            raise ProtocolError(f"could not connect to {self.host}:{self.port}") from error
        if not greeting.startswith("BABEL/2 ") or not prompt.startswith("Send "):
            self.close()
            raise ProtocolError("target greeting was not Tower of Babel BABEL/2")
        print(greeting)
        print(prompt)

    def close(self) -> None:
        if self.reader is not None:
            try:
                self.reader.close()
            except OSError:
                pass
            self.reader = None
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None

    def _readline(self) -> str:
        if self.reader is None:
            raise ProtocolError("the lobby is disconnected")
        raw = self.reader.readline(MAX_LINE_BYTES + 1)
        if not raw:
            raise ProtocolError("target closed the connection")
        if len(raw) > MAX_LINE_BYTES:
            raise ProtocolError("target response exceeded the protocol limit")
        try:
            return raw.decode("utf-8").rstrip("\r\n")
        except UnicodeDecodeError as error:
            raise ProtocolError("target response was not UTF-8") from error

    def _send(self, command: str) -> None:
        if self.sock is None:
            raise ProtocolError("the lobby is disconnected")
        if not command or "\r" in command or "\n" in command:
            raise ValueError("commands must be one line")
        self.sock.sendall((command + "\n").encode("utf-8"))

    def request(self, command: str) -> list[str]:
        """Send one public command and collect its bounded response sequence."""
        self._send(command)
        name = command.split(" ", 1)[0].upper()
        first = self._readline()
        lines = [first]
        if name == "HELLO" and first.startswith("WELCOME "):
            lines.append(self._readline())
        elif name == "RELAY" and not first.startswith("ERR "):
            while True:
                line = self._readline()
                lines.append(line)
                if line.startswith("RELAY_RESULT "):
                    try:
                        result = json.loads(line[len("RELAY_RESULT "):])
                    except json.JSONDecodeError:
                        break
                    if result.get("depth") == 4 and result.get("status") == "complete":
                        lines.append(self._readline())
                    break
        elif name == "AUTH" and first == "RELAY_ACCEPTED":
            lines.append(self._readline())
        return lines

    @staticmethod
    def _json_from_line(line: str, prefix: str) -> dict[str, Any] | None:
        if not line.startswith(prefix):
            return None
        try:
            value = json.loads(line[len(prefix):])
        except json.JSONDecodeError:
            return None
        return value if isinstance(value, dict) else None

    def join(self) -> None:
        if self.joined:
            print("Already joined this connection's wave.")
            return
        token = self.token
        if not token:
            token = getpass.getpass("Current KotH capability (hidden): ").strip()
        if not token:
            print("No capability entered.")
            return
        lines = self.request(f"HELLO {token}")
        for line in lines:
            print(line)
        info = self._json_from_line(lines[-1], "INFO ") if len(lines) > 1 else None
        if lines and lines[0].startswith("WELCOME ") and info is not None:
            self.joined = True
            self.info = info
            print("Joined.")
        else:
            print("The target did not accept the capability.")

    def show_info(self) -> None:
        lines = self.request("INFO")
        for line in lines:
            print(line)
        value = self._json_from_line(lines[0], "INFO ")
        if value is not None:
            self.info = value
            self._print_briefing(value)

    def show_status(self) -> None:
        if not self.joined:
            print("Join the current wave first.")
            return
        lines = self.request("STATUS")
        for line in lines:
            value = self._json_from_line(line, "STATUS ")
            if value is not None:
                print(json.dumps(value, indent=2, sort_keys=True))
            else:
                print(line)

    def show_lore(self) -> None:
        print(textwrap.dedent(LORE).strip())

    @staticmethod
    def _print_briefing(value: dict[str, Any]) -> None:
        ends = value.get("waveEndsAtUnixMs")
        if isinstance(ends, int):
            remaining = max(0, ends - int(time.time() * 1000)) / 1000
            clock = f"{remaining:.1f}s remaining"
        else:
            clock = "clock unavailable"
        print(f"\nWave {value.get('waveId', '?')} ({clock})")
        print("Order: " + " -> ".join(str(item) for item in value.get("order", [])))
        for stage in value.get("stages", []):
            print(
                f"  {stage.get('name', '?'):20} {stage.get('arch', '?'):9}"
                f"  secret={stage.get('secretPath', '?')}"
            )
        ward = value.get("ward")
        if isinstance(ward, dict):
            print(
                "Ward: status={status} revision={revision} owner={owner} fallback={fallback}".format(
                    status=ward.get("status"),
                    revision=ward.get("revision"),
                    owner=ward.get("owner"),
                    fallback=ward.get("fallback"),
                )
            )

    def protocol_console(self) -> None:
        print("Protocol console. Type 'back' to return to the lobby.")
        while True:
            try:
                command = input("protocol> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                return
            if not command:
                continue
            if command.lower() in {"back", "b"}:
                return
            try:
                lines = self.request(command)
            except (OSError, ProtocolError) as error:
                print(f"Protocol error: {error}")
                return
            for line in lines:
                print(line)
            if command.split(" ", 1)[0].upper() == "QUIT":
                self.close()
                return

    def run(self) -> None:
        self.connect()
        if self.token:
            self.join()
        try:
            while self.sock is not None:
                print(
                    textwrap.dedent(
                        """
                        \n                        ╔══════════════════════════════════════════════╗
                        ║              TOWER OF BABEL                 ║
                        ║             interactive lobby              ║
                        ╚══════════════════════════════════════════════╝
                        1. Join current wave
                        2. Wave briefing (INFO)
                        3. My wave status (STATUS)
                        4. Lore
                        5. Rules
                        6. Protocol console
                        7. Quit
                        """
                    ).strip("\n")
                )
                try:
                    choice = input("babel> ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    print()
                    return
                try:
                    if choice in {"1", "join"}:
                        self.join()
                    elif choice in {"2", "info", "briefing"}:
                        self.show_info()
                    elif choice in {"3", "status"}:
                        self.show_status()
                    elif choice in {"4", "lore"}:
                        self.show_lore()
                    elif choice in {"5", "rules"}:
                        print(textwrap.dedent(RULES).strip())
                    elif choice in {"6", "console"}:
                        self.protocol_console()
                    elif choice in {"7", "quit", "q"}:
                        for line in self.request("QUIT"):
                            print(line)
                        return
                    else:
                        print("Choose 1-7, or type the matching word.")
                except (OSError, ProtocolError, ValueError) as error:
                    print(f"Protocol error: {error}")
                    return
        finally:
            self.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True, help="issued Tower TCP host")
    parser.add_argument("--port", type=int, default=1094, help="issued Tower TCP port")
    parser.add_argument("--token", help="optional capability for local automation; prompt is safer")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be in 1..65535")
    console = BabelConsole(args.host, args.port, args.token)
    try:
        console.run()
    except (OSError, ProtocolError, ValueError) as error:
        parser.exit(1, f"client failed: {error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
